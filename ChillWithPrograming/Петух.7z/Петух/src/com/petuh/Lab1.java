package com.petuh;

public class Lab1 {

}
